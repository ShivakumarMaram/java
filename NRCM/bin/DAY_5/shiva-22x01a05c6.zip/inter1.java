package DAY_5;

public class inter1 {
	

}
